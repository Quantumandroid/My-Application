<?php
	define('HOST','localhost');
	define('USER','mandu');
	define('PASS','1234');
	define('DB','andro');
	
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>